package com.logsToElasticSearch;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ElasticSearchApi {

	public static void main(String[] args) {

		ElasticSearchApi ct = new ElasticSearchApi();

		System.out.println(ct.currentTimestamp());

	}

	public String currentTimestamp() {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Date date = new Date();
		String CurrentTimeStamp = sdf.format(date);
		return CurrentTimeStamp;

	}

}
