package com.logsToElasticSearch;

public class Article {

	private String Author;
	private String Content;

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public String getContent() {
		return Content;
	}

	public void setContent(String content) {
		Content = content;
	}

	@Override
	public String toString() {
		return "Article [Author=" + Author + ", Content=" + Content + "]";
	}

}
