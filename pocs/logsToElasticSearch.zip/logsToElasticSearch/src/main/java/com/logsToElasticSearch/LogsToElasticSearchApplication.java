package com.logsToElasticSearch;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Bulk;
import io.searchbox.core.Index;

@SpringBootApplication
public class LogsToElasticSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogsToElasticSearchApplication.class, args);

		// Construct a new Jest client according to configuration via factory
		String connectionUrl = "http://localhost:9200/";
		JestClientFactory factory = new JestClientFactory();
		factory.setHttpClientConfig(new HttpClientConfig.Builder(connectionUrl).multiThreaded(true).build());
		JestClient client = factory.getObject();

		// create the one time index:---
		/*try {
			client.execute(new CreateIndex.Builder("articles-check").build());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Article source = new Article();
		source.setAuthor("John Ronald Reuel Tolkien");
		source.setContent("The Lord of the Rings is an epic high fantasy novel");

		Index index = new Index.Builder(source).index("articles-check").type("article-chk").build();
		try {
			client.execute(index);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		Article article1 = new Article();
       
        article1.setAuthor("ok 2 Robert Anthony Salvatore");
        article1.setContent("Homeland follows the story of Drizzt from around the time and circumstances of his birth and his upbringing amongst the drow (dark elves). " +
                "The book takes the reader into Menzoberranzan, the drow home city. From here, the reader follows Drizzt on his quest to follow his principles in a land where such " +
                "feelings are threatened by all his family including his mother Matron Malice. In an essence, the book introduces Drizzt Do'Urden," +
                " one of Salvatore's more famous characters from the Icewind Dale Trilogy.");

        Article article2 = new Article();
        article2.setAuthor("ok 33 John Ronald Reuel Tolkien");
        article2.setContent("The Lord of the Rings is an epic high fantasy novel written by English philologist and University of Oxford professor J. R. R. Tolkien. " +
                "The story began as a sequel to Tolkien's 1937 children's fantasy novel The Hobbit, but eventually developed into a much larger work. " +
                "It was written in stages between 1937 and 1949, much of it during World War II.[1] It is the third best-selling novel ever written, with over 150 million copies sold");

        try {
           /* // Delete articles index if it is exists
            DeleteIndex deleteIndex = new DeleteIndex("articles");
            client.execute(deleteIndex);

            // Create articles index
            CreateIndex createIndex = new CreateIndex("articles");
            jestClient.execute(createIndex);*/

            /**
             *  if you don't want to use bulk api use below code in a loop.
             *
             *  Index index = new Index.Builder(new Object()).index("articles").type("article").build();
             *  elasticSearchClient.execute(index);
             *
             */

        	// Construct Bulk request from articles
        	Bulk bulk = new Bulk.Builder()
        	                .defaultIndex("twitter")
        	                .defaultType("tweet")
        	                .addAction(Arrays.asList(
        	                    new Index.Builder(article1).build(),
        	                    new Index.Builder(article2).build()))
        	                .build();

        	try {
				client.execute(bulk);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

           
	} finally {
		
	}
        
        
        
        
        
}
	
}
